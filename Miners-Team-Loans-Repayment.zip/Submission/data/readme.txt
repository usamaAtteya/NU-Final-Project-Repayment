Download data from https://ed-public-download.app.cloud.gov/downloads/CollegeScorecard_Raw_Data.zip
And extract it here